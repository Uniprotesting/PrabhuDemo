from Pages.ApplicationName import applicationNamePage
from Pages.ApplicationType import applicationTypePage
from Pages.Login_OktaAuthentication import loginPage
from Tests.conftest import browser


class TestNavigationE2e():

    def test_valid_login(self,browser):
        lp = loginPage(browser)
        lp.test_login()
        pass

    def test_application_Type(self, browser):

        ap = applicationTypePage(browser)
        ap.test_level_button_functionality()
        ap.test_appType_heading_visible()
        ap.test_appType_page_title()
        ap.test_appType_heading()
        ap.test_ALLELEMENTS_Present()
        pass



    def test_application_Name(self, browser):

        an = applicationNamePage(browser)
        an.test_appName_title()
        an.test_serviceName_title()
        an.test_appName_heading()
        an.test_NullFields()
        an.test_enter_values()
        an.test_navigationWithAppNameBlank()
        an.test_navigationWithServiceNameBlank()
        an.test_navigationWithAppAndServiceNameBlank()
        pass

    pass

