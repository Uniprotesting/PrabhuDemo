from selenium.webdriver.common.by import By
from Config.config import TestData

from base.selenium_driver import SeleniumDriver


class applicationTypePage(SeleniumDriver):

    """By Locators - Object Repository"""

    appTypeHeading = (By.XPATH, "//h3[contains(text(),'Application Type')]")
    levelName = (By.XPATH, "//div[normalize-space(text()) = 'Level']")
    levelTile = (By.XPATH, "//div[normalize-space(text()) = 'Level']/ancestor::div/button")
    levelTile_CSS = (By.CSS_SELECTOR,"#Level")
    level_text_css=(By.CSS_SELECTOR,"#root > div > div.sc-1bs241c-0.gJbtcV > div.sc-1bs241c-1.kRojQU > div")

    nextButton = (By.XPATH, "//*[@id='root']/div/div[1]/div[2]/div[2]/button")
    appTypeAccord = (By.XPATH, "//*[@id='root']/div/div[2]/div")



    def __init__(self, driver):
        super().__init__(driver)




    def is_appType_exists(self):
        return self.is_visible(self.appTypeHeading)

    def check_heading(self):
        resp = self.headingCheck(self.appTypeHeading)
        return resp

    def is_level_visible(self):
        return self.is_visible(self.levelTile_CSS)

    def is_AppType_Accordion_Exists(self):
        return self.is_visible(self.appTypeAccord)

    def is_Next_Button_Visible(self):
        return self.is_visible(self.nextButton)

    def click_nextButton(self):
        self.do_click(self.nextButton)
        pass

    def click_level_button(self):
        self.do_click(self.levelTile_CSS)
        pass

    def get_text_value_for_level(self):

       self. get_text_from_element(self.level_text_css)
       pass



    def test_appType_heading_visible(self):

        flag = self.is_appType_exists()
        print("Control in Application Type Page")
        assert flag, "Not in Application Type Page"

    def test_appType_page_title(self):

        actual_title = TestData.APP_TYPE_PAGE_TITLE
        expected_title = self.get_title()
        print("\n Expected Title is: ", expected_title)
        print("\n Actual Title is: ", actual_title)
        self.log.info("Checking the Application Name Page Title")
        assert actual_title == expected_title, "Page Title doesn't match"


    def test_appType_heading(self):

        print("\n Page Heading is: ", self.check_heading())
        assert TestData.APPLICATION_TYPE_PAGE_HEADING == self.check_heading(), "Heading doesn't match"


    def test_ALLELEMENTS_Present(self):

        levelBtn = self.is_level_visible()

        print("Checking if Level button in Application Type Page exists")
        assert levelBtn, "Level button in Application Type Page doesn't exists"

        nextBtn = self.is_Next_Button_Visible()
        print("Checking if Next button in Application Type Page exists")
        assert nextBtn, "Next button in Application Type Page doesn't exists"

        appTypeAccord = self.is_AppType_Accordion_Exists()
        print("Checking if Next button in Application Type Page exists")
        assert appTypeAccord, "Accordian Type in Application Type Page doesn't exists"

        self.click_nextButton()
        print(" Clicked on next button ")



    def test_level_button_functionality(self):
        self.click_level_button()
        print("The text of an element after the clicking the level button ",self.get_text_value_for_level())

        pass