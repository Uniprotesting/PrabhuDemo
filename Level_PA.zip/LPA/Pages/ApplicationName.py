from selenium.webdriver.common.by import By
from Config.config import TestData

from base.selenium_driver import SeleniumDriver


class applicationNamePage(SeleniumDriver):

    """By Locators - Object Repository"""

    appName = (By.ID, "application-name-textfield")
    appNameHeading = (By.XPATH, "//label[contains(text(),'APPLICATION NAME')]")
    serviceNameHeading = (By.XPATH, "//label[contains(text(),'SERVICE')]")
    heading = (By.XPATH, "//h3[contains(text(),'Application Name')]")
    serviceName = (By.ID, "service-textfield")
    nextButton = (By.XPATH, "//*[@id='root']/div/div[1]/div[2]/div[2]/button")
    nextButton_css=(By.CSS_SELECTOR,"button.sc-159dgud-0.hVNBvP")
    previousButton = (By.CSS_SELECTOR,"button.sc-159dgud-0.dUqMiT")
    appNameAccord = (By.XPATH, "//div[normalize-space(text()) = 'ApplicationName']")
    textOfAppNameAccord = (By.XPATH, "//div[normalize-space(text()) = 'ApplicationName']/descendant::*")

    """Constructor"""
    def __init__(self, driver):
        super().__init__(driver)
        self.driver.implicitly_wait(15)
        self.driver.maximize_window()
        #self.driver.get(TestData.BASE_URL)

    """Page Actions"""

    def is_appName_exists(self):
        return self.is_visible(self.appName)

    def do_appName(self, value):
        self.do_send_keys(self.appName, value)

    def check_heading(self):
        resp = self.headingCheck(self.heading)
        return resp

    def element_title(self):
        resp = self.elementTitle(self.appNameHeading)
        return resp

    def element_title2(self):
        resp = self.elementTitle(self.serviceNameHeading)
        return resp

    def is_serviceName_exists(self):
        return self.is_visible(self.serviceName)

    def do_serviceName(self, value):
        self.do_send_keys(self.serviceName, value)

    def click_next(self):
        return self.do_click(self.nextButton_css)

    def get_appNameAccord(self):
        self.get_accordAttribute(self.appNameAccord)

    def get_appName_value(self):
        self.getProperty(self.appName)

    def get_appNameAccordion_value(self):
        self.getProperty(self.appNameAccord)

    def is_appNameAccordion_exists(self):
        return self.is_visible(self.appNameAccord)

    def click_previous(self):
        return self.do_click(self.previousButton)





    def test_appName_input_visible(self):

        flag = self.is_appName_exists()
        self.log.info("Control in Application Name Page")
        assert flag, "Not in Application Name Page"


    def test_appName_title(self):

        print("\n Application Name Field title is: ", self.element_title())
        assert TestData.APPLICATION_NAME_ELEMENT_TITLE == self.element_title(), "Page Title doesn't match"


    def test_serviceName_title(self):

        print("\n Service Name Field is: ", self.element_title2())
        assert TestData.SERVICE_NAME_ELEMENT_TITLE == self.element_title2(), "Page Title doesn't match"


    def test_appName_heading(self):

        print("\n Page Heading is: ", self.check_heading())
        assert TestData.APPLICATION_NAME_PAGE_HEADING == self.check_heading(), "Heading doesn't match"

    """ Test Case to check if Application Name, and Service Name Text Fields are Null to start """


    def test_NullFields(self):

        appNameText = self.getProperty(self.appName)
        serviceNameText = self.getProperty(self.serviceName)
        assert len(appNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Application Name Text field has no input -- Null ")
        assert len(serviceNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Service Name Text field has no input -- Null ")
    """
    def test_appNameAccord(self):
        self.appName = applicationNamePage(self.driver)
        applicationName = TestData.APPLICATION_NAME_TEXT
        inp = self.appName.do_appName(applicationName[:40])

        print("Value entered into Application Name Text Field is: ", inp)
        accord = self.appName.getProperty(self.appName.textOfappNameAccord)
        print("Value inside the accordian is", accord)
    """


    def test_enter_values(self):

        field_present = self.is_appName_exists()
        counter = 0
        if field_present:
            applicationName = TestData.APPLICATION_NAME_TEXT
            if len(applicationName) > 0 & len(applicationName) <= 40:
                string = []
                special_char = []
                for i in applicationName:
                    if i.isalnum() | i.isdigit():
                        string.append(i)
                    else:
                        special_char.append(i)
                print("Application Name Alphanumeric ", string)
                print("Special characters in Application Name input: ", special_char)
            elif len(applicationName) == 0:
                counter = 1
                print("\n No input given, enter the Application Name")
            """Entering only 40 characters"""
            self.do_appName(applicationName[:40])
            print("Input entered into Application Name Field is: ", applicationName[:40])
            #accord = self.appName.get_appNameAccord()
            #print("Value inside the accordian is", accord)
        else:
            print("Application Name field not found")


        """
        Entering value into Service Name Text Box
        :return:
        """

        field_present2 = self.is_serviceName_exists()
        counter2 = 0
        if field_present2:
            service_name = TestData.SERVICE_NAME_TEXT
            if len(service_name) > 0 & len(service_name) <= 40:
                string = []
                special_char = []
                for i in service_name:
                    if i.isalnum() | i.isdigit():
                        string.append(i)
                    else:
                        special_char.append(i)
                print("Service Name Alphanumeric ", string)
                print("Special characters in Service Name input: ", special_char)
            elif len(service_name) == 0:
                counter2 = 1
                print("\n No input given, provide the Service Name")
            """Entering only 40 characters"""
            self.do_serviceName(service_name[:40])
            print("Input entered into Service Name Field is: ", service_name[:40])
        else:
            print("Service Name field not found")

        assert counter == 0, "Application Name is invalid"
        assert counter2 == 0, "Service Name is invalid"

        """Clicking on Next Button"""

        self.click_next()
        #assert self.next_page_check(), "Failed to Reach Application Type Page"


    def test_navigationWithAppNameBlank(self):
        print(self.get_title())

        self.click_previous()

        service_name = TestData.SERVICE_NAME_TEXT
        self.do_serviceName(service_name[:40])
        self.click_next()

        # if self.appName.next_page_check():
        #     bool1 = True
        #     assert not bool1, "Page Navigated to Application Type Page with blank Application Name Field"


    def test_navigationWithServiceNameBlank(self):
        print(self.get_title())

        self.click_previous()
        applicationName = TestData.APPLICATION_NAME_TEXT
        self.do_appName(applicationName[:40])

        self.click_next()

        # if self.next_page_check():
        #     bool1 = True
        #     assert not bool1, "Page Navigated to Application Type Page with blank Service Name Field"


    def test_navigationWithAppAndServiceNameBlank(self):

        self.click_next()

        # if self.appName.next_page_check():
        #     bool1 = True
        #     assert not bool1, "Page Navigated to Application Type Page with blank Application and Service Name Field"



