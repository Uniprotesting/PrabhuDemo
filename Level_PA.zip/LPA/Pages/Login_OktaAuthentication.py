from selenium.webdriver.common.by import By
from Config.config import TestData
from base.selenium_driver import SeleniumDriver


class loginPage(SeleniumDriver):
    """By Locators - Object Repository"""

    userName = (By.ID, "idp-discovery-username")
    nextButton = (By.ID, "idp-discovery-submit")
    password = (By.ID, "okta-signin-password")
    signIn = (By.ID, "okta-signin-submit")
    securityQuestionDropDown = (By.XPATH, "//div[@class='dropdown more-actions float-l']")
    securityQuestionOption = (By.XPATH, "//div[@id='okta-dropdown-options']/descendant::span[contains(text(),'')][2]")
    securityAnswer = (By.XPATH, "//input[@type='password' and @name='answer']")
    verify = (By.XPATH, "//input[@value='Verify']")

    """Constructor"""

    def __init__(self, driver):
        super().__init__(driver)



    """ Page Actions """
    def is_UserName_Present(self):
        return self.is_visible(self.userName)

    def do_UserName(self, value):
        self.do_send_keys(self.userName, value)

    def is_NextButton_Present(self):
        return self.is_visible(self.nextButton)

    def click_next(self):
        return self.do_click(self.nextButton)

    def is_Password_Present(self):
        return self.is_visible(self.password)

    def do_Password(self, value):
        self.do_send_keys(self.password, value)

    def is_SignIn_Present(self):
        return self.is_visible(self.signIn)

    def click_SignIn(self):
        return self.do_click(self.signIn)

    def is_securityAnswer_Present(self):
        return self.is_visible(self.securityAnswer)

    def do_SecurityAnswer(self, value):
        self.do_click(self.securityAnswer)
        self.do_send_keys(self.securityAnswer, value)

    def is_verify_Present(self):
        return self.is_visible(self.verify)

    def click_Verify(self):
        return self.do_click(self.verify)


    def test_login(self):
        userName = TestData.EMAIL_ADDRESS
        password = TestData.PASSWORD
        secAnswer = TestData.SECURITY_ANSWER
        if self.is_UserName_Present():
            self.do_UserName(userName)
            print("User Name Entered \n")
        else:
            print("User Name field not present \n")
        if self.is_NextButton_Present():
            self.click_next()
            print("Clicking on Next button \n")
        else:
            print("Unable to click on Next Button \n")
        if self.is_Password_Present():
            self.do_Password(password)
            print("Password Entered \n")
        else:
            print("Unable to locate Password field \n")
        if self.is_SignIn_Present():
            self.click_SignIn()
            print("Clicking on Sign In button \n")
        else:
            print("Unable to click on Sign In Button \n")
        if self.is_securityAnswer_Present():
            self.do_SecurityAnswer(secAnswer)
            print("Entering Security Answer \n")
        else:
            print("Unable to fill in Security Answer \n")
        self.click_Verify()



