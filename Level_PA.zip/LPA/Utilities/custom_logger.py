import inspect
import logging


def customLogger(loglevel=logging.DEBUG):

    loggerName = inspect.stack()[1][3]
    logger = logging.getLogger(loggerName)
    logger.setLevel(logging.DEBUG)

    fileHandler = logging.FileHandler("logs.log", mode='a')
    fileHandler.setLevel(loglevel)

    formatter = logging.Formatter("%(asctime)s-%(levelname)s-%(message)s")

    fileHandler.setFormatter(formatter)
    logger.addHandler(fileHandler)

    return logger


