from selenium.webdriver.common.by import By
from Config.config import TestData
from Pages.BasePage import BasePage


class loginPage(BasePage):
    """By Locators - Object Repository"""

    userName = (By.ID, "idp-discovery-username")
    nextButton = (By.ID, "idp-discovery-submit")
    password = (By.ID, "okta-signin-password")
    signIn = (By.ID, "okta-signin-submit")
    securityQuestionDropDown = (By.XPATH, "//div[@class='dropdown more-actions float-l']")
    securityQuestionOption = (By.XPATH, "//div[@id='okta-dropdown-options']/descendant::span[contains(text(),'')][2]")
    securityAnswer = (By.XPATH, "//input[@type='password' and @name='answer']")
    verify = (By.XPATH, "//input[@value='Verify']")

    """Constructor"""

    def __init__(self, browser):
        super().__init__(browser)
        self.driver.implicitly_wait(15)
        self.driver.maximize_window()


    """ Page Actions """
    def is_UserName_Present(self):
        return self.is_visible(self.userName)

    def do_UserName(self, value):
        self.do_send_keys(self.userName, value)

    def is_NextButton_Present(self):
        return self.is_visible(self.nextButton)

    def click_next(self):
        return self.do_click(self.nextButton)

    def is_Password_Present(self):
        return self.is_visible(self.password)

    def do_Password(self, value):
        self.do_send_keys(self.password, value)

    def is_SignIn_Present(self):
        return self.is_visible(self.signIn)

    def click_SignIn(self):
        return self.do_click(self.signIn)

    def is_securityAnswer_Present(self):
        return self.is_visible(self.securityAnswer)

    def do_SecurityAnswer(self, value):
        self.do_click(self.securityAnswer)
        self.do_send_keys(self.securityAnswer, value)

    def is_verify_Present(self):
        return self.is_visible(self.verify)

    def click_Verify(self):
        return self.do_click(self.verify)

