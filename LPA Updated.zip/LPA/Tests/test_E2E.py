import unittest



from Tests.test_Login_Okta_Authentication import Test_Login
from Tests.test_applicationNamePage import Test_AppName
from Tests.test_applicationTypePage import Test_AppType


class test_E2E():


    def test_e2e(self,browser):
        Test_Login()
        Test_AppType()
        #Test_AppName()
        pass



