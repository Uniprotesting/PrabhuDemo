import pytest
import pytest_html
from Config.config import TestData
from Pages.ApplicationName import applicationNamePage
from Pages.BasePage import BasePage

from Utilities.custom_logger import customLogger as cl
import logging


class Test_AppName():
    log = cl(logging.DEBUG)

    @pytest.mark.run(order=6)
    def test_appName_input_visible(self,browser):
        self.appName = applicationNamePage(browser.driver)
        flag = self.appName.is_appName_exists()
        self.log.info("Control in Application Name Page")
        assert flag, "Not in Application Name Page"

    @pytest.mark.run(order=7)
    def test_appName_title(self,browser):
        self.appName = applicationNamePage(browser.driver)
        print("\n Application Name Field title is: ", self.appName.element_title())
        assert TestData.APPLICATION_NAME_ELEMENT_TITLE == self.appName.element_title(), "Page Title doesn't match"

    @pytest.mark.run(order=8)
    def test_serviceName_title(self,browser):
        self.appName = applicationNamePage(browser.driver)
        print("\n Service Name Field is: ", self.appName.element_title2())
        assert TestData.SERVICE_NAME_ELEMENT_TITLE == self.appName.element_title2(), "Page Title doesn't match"

    @pytest.mark.run(order=9)
    def test_appName_heading(self,browser):
        self.appName = applicationNamePage(browser.driver)
        print("\n Page Heading is: ", self.appName.check_heading())
        assert TestData.APPLICATION_NAME_PAGE_HEADING == self.appName.check_heading(), "Heading doesn't match"

    """ Test Case to check if Application Name, and Service Name Text Fields are Null to start """

    @pytest.mark.run(order=10)
    def test_NullFields(self,browser):
        self.appName = applicationNamePage(browser.driver)
        appNameText = self.appName.getProperty(self.appName.appName)
        serviceNameText = self.appName.getProperty(self.appName.serviceName)
        assert len(appNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Application Name Text field has no input -- Null ")
        assert len(serviceNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Service Name Text field has no input -- Null ")
    """
    def test_appNameAccord(self):
        self.appName = applicationNamePage(self.driver)
        applicationName = TestData.APPLICATION_NAME_TEXT
        inp = self.appName.do_appName(applicationName[:40])

        print("Value entered into Application Name Text Field is: ", inp)
        accord = self.appName.getProperty(self.appName.textOfappNameAccord)
        print("Value inside the accordian is", accord)
    """

    @pytest.mark.run(order=11)
    def test_enter_values(self,browser):
        self.appName = applicationNamePage(browser.driver)
        field_present = self.appName.is_appName_exists()
        counter = 0
        if field_present:
            applicationName = TestData.APPLICATION_NAME_TEXT
            if len(applicationName) > 0 & len(applicationName) <= 40:
                string = []
                special_char = []
                for i in applicationName:
                    if i.isalnum() | i.isdigit():
                        string.append(i)
                    else:
                        special_char.append(i)
                print("Application Name Alphanumeric ", string)
                print("Special characters in Application Name input: ", special_char)
            elif len(applicationName) == 0:
                counter = 1
                print("\n No input given, enter the Application Name")
            """Entering only 40 characters"""
            self.appName.do_appName(applicationName[:40])
            print("Input entered into Application Name Field is: ", applicationName[:40])
            #accord = self.appName.get_appNameAccord()
            #print("Value inside the accordian is", accord)
        else:
            print("Application Name field not found")


        """
        Entering value into Service Name Text Box
        :return:
        """

        field_present2 = self.appName.is_serviceName_exists()
        counter2 = 0
        if field_present2:
            service_name = TestData.SERVICE_NAME_TEXT
            if len(service_name) > 0 & len(service_name) <= 40:
                string = []
                special_char = []
                for i in service_name:
                    if i.isalnum() | i.isdigit():
                        string.append(i)
                    else:
                        special_char.append(i)
                print("Service Name Alphanumeric ", string)
                print("Special characters in Service Name input: ", special_char)
            elif len(service_name) == 0:
                counter2 = 1
                print("\n No input given, provide the Service Name")
            """Entering only 40 characters"""
            self.appName.do_serviceName(service_name[:40])
            print("Input entered into Service Name Field is: ", service_name[:40])
        else:
            print("Service Name field not found")

        assert counter == 0, "Application Name is invalid"
        assert counter2 == 0, "Service Name is invalid"

        """Clicking on Next Button"""

        self.appName.click_next()
        assert self.appName.next_page_check(), "Failed to Reach Application Type Page"

    @pytest.mark.run(order=12)
    def test_navigationWithAppNameBlank(self,browser):
        self.appName = applicationNamePage(browser.driver)
        service_name = TestData.SERVICE_NAME_TEXT
        self.appName.do_serviceName(service_name[:40])
        self.appName.click_next()

        if self.appName.next_page_check():
            bool1 = True
            assert not bool1, "Page Navigated to Application Type Page with blank Application Name Field"

    @pytest.mark.run(order=13)
    def test_navigationWithServiceNameBlank(self,browser):
        self.appName = applicationNamePage(self.driver)
        applicationName = TestData.APPLICATION_NAME_TEXT
        self.appName.do_appName(applicationName[:40])

        self.appName.click_next()

        if self.appName.next_page_check():
            bool1 = True
            assert not bool1, "Page Navigated to Application Type Page with blank Service Name Field"

    @pytest.mark.run(order=14)
    def test_navigationWithAppAndServiceNameBlank(self,browser):
        self.appName = applicationNamePage(browser.driver)
        self.appName.click_next()

        if self.appName.next_page_check():
            bool1 = True
            assert not bool1, "Page Navigated to Application Type Page with blank Application and Service Name Field"

