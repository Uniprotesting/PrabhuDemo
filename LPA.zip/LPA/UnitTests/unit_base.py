import pytest


@pytest.mark.usefixtures("init_driver")
class UnitTest:
    pass

