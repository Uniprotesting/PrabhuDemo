import pytest
import pytest_html
from Config.config import TestData
from Pages.ApplicationName import applicationNamePage
from UnitTests.unit_base import UnitTest
from Utilities.custom_logger import customLogger as cl
import logging


class Test_AppNameUnitTest(UnitTest):
    log = cl(logging.DEBUG)

    def test_appName_input_visible(self):
        self.appName = applicationNamePage(self.driver)
        flag = self.appName.is_appName_exists()
        self.log.info("Control in Application Name Page")
        assert flag, "Not in Application Name Page"

    def test_appName_page_title(self):
        self.appName = applicationNamePage(self.driver)
        actual_title = TestData.APP_NAME_PAGE_TITLE
        expected_title = self.appName.driver.title
        print("\n Expected Title is: ", expected_title)
        print("\n Actual Title is: ", actual_title)
        self.log.info("Checking the Application Name Page Title")
        assert actual_title == expected_title, "Page Title doesn't match"

    def test_appName_title(self):
        self.appName = applicationNamePage(self.driver)
        print("\n Application Name Field title is: ", self.appName.element_title())
        assert TestData.APPLICATION_NAME_ELEMENT_TITLE == self.appName.element_title(), "Page Title doesn't match"

    def test_serviceName_title(self):
        self.appName = applicationNamePage(self.driver)
        print("\n Service Name Field is: ", self.appName.element_title2())
        assert TestData.SERVICE_NAME_ELEMENT_TITLE == self.appName.element_title2(), "Page Title doesn't match"

    def test_appName_heading(self):
        self.appName = applicationNamePage(self.driver)
        print("\n Page Heading is: ", self.appName.check_heading())
        assert TestData.APPLICATION_NAME_PAGE_HEADING == self.appName.check_heading(), "Heading doesn't match"

    """ Test Case to check if Application Name, and Service Name Text Fields are Null to start """
    def test_NullFields(self):
        self.appName = applicationNamePage(self.driver)
        appNameText = self.appName.getProperty(self.appName.appName)
        serviceNameText = self.appName.getProperty(self.appName.serviceName)
        assert len(appNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Application Name Text field has no input -- Null ")
        assert len(serviceNameText) == 0, "Application Name Text field has input, hence failing the Test Case"
        print("Service Name Text field has no input -- Null ")

    def test_enter_values(self):
        self.appName = applicationNamePage(self.driver)
        field_present = self.appName.is_appName_exists()
        counter = 0
        if field_present:
            applicationName = TestData.APPLICATION_NAME_TEXT
            self.appName.do_appName(applicationName[:40])
            print("Input entered into Application Name Field is: ", applicationName[:40])
        else:
            print("Application Name field not found")

        """ Entering value into Service Name Text Box """

        field_present2 = self.appName.is_serviceName_exists()
        counter2 = 0
        if field_present2:
            service_name = TestData.SERVICE_NAME_TEXT
            self.appName.do_serviceName(service_name[:40])
            print("Input entered into Service Name Field is: ", service_name[:40])
        else:
            print("Service Name field not found")

        assert counter == 0, "Application Name is invalid"
        assert counter2 == 0, "Service Name is invalid"

        """Clicking on Next Button"""
        self.appName.click_next()
        assert self.appName.next_page_check(), "Failed to Reach Application Type Page"

    def test_appNameAccordion(self):
        self.appName = applicationNamePage(self.driver)
        flag = self.appName.is_appNameAccordion_exists()
        self.log.info("Application Name Accordion test")
        assert flag, "Application Name Accordion doesn't exist"

