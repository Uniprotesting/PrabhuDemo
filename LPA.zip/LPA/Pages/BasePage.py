from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select


class BasePage:

    def __init__(self, driver):
        self.driver = driver

    def do_click(self, by_locator):
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator)).click()

    def do_send_keys(self, by_locator, text):
        WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator)).send_keys(text)

    def get_element_text(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator))
        return element.text

    def is_visible(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator))
        return bool(element)

    def headingCheck(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator))
        return element.text

    def elementTitle(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.visibility_of_element_located(by_locator))
        return element.text

    def getProperty(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(by_locator))
        return element.get_property('value')

    def get_accordAttribute(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.presence_of_element_located(by_locator))
        return element.get_property('value')

    def position_css_property(self, by_locator):
        element = WebDriverWait(self.driver, 20).until(EC.element_to_be_clickable(by_locator))
        result = element.value_of_css_property("display")
        return result


