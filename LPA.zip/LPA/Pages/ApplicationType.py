from selenium.webdriver.common.by import By
from Config.config import TestData
from Pages.BasePage import BasePage


class applicationTypePage(BasePage):

    """By Locators - Object Repository"""

    appTypeHeading = (By.XPATH, "//h3[contains(text(),'Application Type')]")
    levelName = (By.XPATH, "//div[normalize-space(text()) = 'Level']")
    levelTile = (By.XPATH, "//div[normalize-space(text()) = 'Level']/ancestor::div/button")
    nextButton = (By.XPATH, "//button[contains(text(),'Next')]")
    appTypeAccord = (By.XPATH, "//div[normalize-space(text()) = 'ApplicationName']")

    """Constructor"""
    """
    def __init__(self, driver):
        super().__init__(driver)
        self.driver.implicitly_wait(15)
        self.driver.maximize_window()
        self.driver.get(TestData.BASE_URL)
    """
    """Page Actions"""

    def is_appType_exists(self):
        return self.is_visible(self.appTypeHeading)

    def check_heading(self):
        resp = self.headingCheck(self.appTypeHeading)
        return resp

    def is_level_visible(self):
        return self.is_visible(self.levelTile)

    def is_AppType_Accordion_Exists(self):
        return self.is_visible(self.appTypeAccord)

    def is_Next_Button_Visible(self):
        return self.is_visible(self.nextButton)

    def get_border(self):
        return self.position_css_property(self.levelTile)
