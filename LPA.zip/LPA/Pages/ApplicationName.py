from selenium.webdriver.common.by import By
from Config.config import TestData
from Pages.BasePage import BasePage


class applicationNamePage(BasePage):

    """By Locators - Object Repository"""

    appName = (By.ID, "application-name-textfield")
    appNameHeading = (By.XPATH, "//label[contains(text(),'APPLICATION NAME')]")
    serviceNameHeading = (By.XPATH, "//label[contains(text(),'SERVICE')]")
    heading = (By.XPATH, "//h3[contains(text(),'Application Name')]")
    serviceName = (By.ID, "service-textfield")
    nextButton = (By.XPATH, "//button[contains(text(),'Next')]")
    previousButton = ()
    appNameAccord = (By.XPATH, "//div[normalize-space(text()) = 'ApplicationName']")
    textOfAppNameAccord = (By.XPATH, "//div[normalize-space(text()) = 'ApplicationName']/descendant::*")

    """Constructor"""
    def __init__(self, driver):
        super().__init__(driver)
        self.driver.implicitly_wait(15)
        self.driver.maximize_window()
        self.driver.get(TestData.BASE_URL)

    """Page Actions"""

    def is_appName_exists(self):
        return self.is_visible(self.appName)

    def do_appName(self, value):
        self.do_send_keys(self.appName, value)

    def check_heading(self):
        resp = self.headingCheck(self.heading)
        return resp

    def element_title(self):
        resp = self.elementTitle(self.appNameHeading)
        return resp

    def element_title2(self):
        resp = self.elementTitle(self.serviceNameHeading)
        return resp

    def is_serviceName_exists(self):
        return self.is_visible(self.serviceName)

    def do_serviceName(self, value):
        self.do_send_keys(self.serviceName, value)

    def click_next(self):
        return self.do_click(self.nextButton)

    def get_appNameAccord(self):
        self.get_accordAttribute(self.appNameAccord)

    def get_appName_value(self):
        self.getProperty(self.appName)

    def get_appNameAccordion_value(self):
        self.getProperty(self.appNameAccord)

    def is_appNameAccordion_exists(self):
        return self.is_visible(self.appNameAccord)

