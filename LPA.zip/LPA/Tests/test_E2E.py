import unittest

from Tests.test_Login_Okta_Authentication import Test_Login
from Tests.test_applicationTypePage import Test_AppType


class TestE2E(unittest.TestCase):

    def setUp(self):
        Test_Login().test_login()
        pass

    def test_e2e(self):
        Test_AppType().test_appType_page_title()
        pass

    def tearDown(self):
        pass

    pass