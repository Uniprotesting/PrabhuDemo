from Config.config import TestData
from Pages.ApplicationType import applicationTypePage
from Pages.Login_OktaAuthentication import loginPage
from Tests.test_base import BaseTest
import pytest


class Test_Login(BaseTest):

    def test_login(self):
        self.login = loginPage(self.driver)
        userName = TestData.EMAIL_ADDRESS
        password = TestData.PASSWORD
        secAnswer = TestData.SECURITY_ANSWER
        if self.login.is_UserName_Present():
            self.login.do_UserName(userName)
            print("User Name Entered \n")
        else:
            print("User Name field not present \n")
        if self.login.is_NextButton_Present():
            self.login.click_next()
            print("Clicking on Next button \n")
        else:
            print("Unable to click on Next Button \n")
        if self.login.is_Password_Present():
            self.login.do_Password(password)
            print("Password Entered \n")
        else:
            print("Unable to locate Password field \n")
        if self.login.is_SignIn_Present():
            self.login.click_SignIn()
            print("Clicking on Sign In button \n")
        else:
            print("Unable to click on Sign In Button \n")
        if self.login.is_securityAnswer_Present():
            self.login.do_SecurityAnswer(secAnswer)
            print("Entering Security Answer \n")
        else:
            print("Unable to fill in Security Answer \n")
        self.login.click_Verify()

        self.appType = applicationTypePage(self.driver)
        flag = self.appType.is_appType_exists()
        print("Control in Application Type Page")
        assert flag, "Not in Application Type Page"
