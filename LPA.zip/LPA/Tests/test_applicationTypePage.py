from Config.config import TestData
from Pages.ApplicationType import applicationTypePage
from Tests.test_base import BaseTest
from Utilities.custom_logger import customLogger as cl
import logging
import pytest


class Test_AppType(BaseTest):
    log = cl(logging.DEBUG)

    def test_appType_heading_visible(self):
        self.appType = applicationTypePage(self.driver)
        flag = self.appType.is_appType_exists()
        print("Control in Application Type Page")
        assert flag, "Not in Application Type Page"

    def test_appType_page_title(self):
        self.appType = applicationTypePage(self.driver)
        actual_title = TestData.APP_TYPE_PAGE_TITLE
        expected_title = self.appType.driver.title
        print("\n Expected Title is: ", expected_title)
        print("\n Actual Title is: ", actual_title)
        self.log.info("Checking the Application Name Page Title")
        assert actual_title == expected_title, "Page Title doesn't match"

    def test_appType_heading(self):
        self.appType = applicationTypePage(self.driver)
        print("\n Page Heading is: ", self.appType.check_heading())
        assert TestData.APPLICATION_TYPE_PAGE_HEADING == self.appType.check_heading(), "Heading doesn't match"

    def test_ALLELEMENTS_Present(self):
        self.appType = applicationTypePage(self.driver)
        levelBtn = self.appType.is_level_visible()
        print("Checking if Level button in Application Type Page exists")
        assert levelBtn, "Level button in Application Type Page doesn't exists"

        nextBtn = self.appType.is_Next_Button_Visible()
        print("Checking if Next button in Application Type Page exists")
        assert nextBtn, "Next button in Application Type Page doesn't exists"

        appTypeAccord = self.appType.is_AppType_Accordion_Exists()
        print("Checking if Next button in Application Type Page exists")
        assert appTypeAccord, "Next button in Application Type Page doesn't exists"




